package br.com.barbosa;

public class PrimeiraClasse {

	public static void main(String[] args) {
	    System.out.println("Ola");
	}

}
